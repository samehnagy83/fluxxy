

/// الإعدادات العامة للتطبيق (مناظرة لـ general.dart في Fluxstore)
class GeneralConfig {
  static const appName = 'App Clone';

}
