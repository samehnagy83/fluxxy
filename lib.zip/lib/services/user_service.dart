// import 'dart:convert';
// import '../common/storage/shared_storage.dart';
// import '../common/tools/constants.dart';
// import '../models/entities/user.dart';

// /// خدمة المستخدم: تحتفظ بالمستخدم الحالي وتخزّنه محليًا.
// class UserService {
//   static User? _currentUser;

//   static bool get isLoggedIn => _currentUser?.isLoggedIn ?? false;
//   static User? get currentUser => _currentUser;

//   /// تحميل المستخدم من التخزين المحلي عند تشغيل التطبيق
//   static Future<void> loadUserFromStorage() async {
//     final raw = SharedStorage.getString(AppConstants.keyUserJson);
//     if (raw != null && raw.isNotEmpty) {
//       try {
//         final map = jsonDecode(raw) as Map<String, dynamic>;
//         _currentUser = User.fromJson(map);
//       } catch (_) {
//         _currentUser = null;
//       }
//     } else {
//       _currentUser = null;
//     }
//   }

//   /// محاكاة تسجيل الدخول
//   static Future<bool> login(String email, String password, {String? name}) async {
//     await Future.delayed(const Duration(seconds: 2));

//     if (email.isEmpty || password.isEmpty) return false;

//     final fakeUser = User(
//       id: DateTime.now().millisecondsSinceEpoch.toString(),
//       name: (name?.trim().isNotEmpty == true)
//           ? name!.trim()
//           : email.split('@').first,
//       email: email,
//       token: 'fake_token_${DateTime.now().millisecondsSinceEpoch}',
//       avatar: null,
//       role: 'customer',
//     );

//     return await _persistUser(fakeUser);
//   }


//   /// تسجيل الخروج
//   static Future<void> logout() async {
//     await SharedStorage.remove(AppConstants.keyUserJson);
//     _currentUser = null;
//   }

//   /// تحديث المستخدم الحالي (لو عدّل بياناته مثلاً)
//   static Future<bool> updateUser(User user) async {
//     return await _persistUser(user);
//   }

//   /// دالة مساعدة لحفظ المستخدم في SharedPreferences
//   static Future<bool> _persistUser(User user) async {
//     try {
//       final raw = jsonEncode(user.toJson());
//       await SharedStorage.setString(AppConstants.keyUserJson, raw);
//       _currentUser = user;
//       return true;
//     } catch (_) {
//       return false;
//     }
//   }
// }

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/entities/user.dart';

/// 🟢 UserService
/// مسؤول عن حفظ واسترجاع بيانات المستخدم محليًا (SharedPreferences)
/// تمامًا زي Fluxstore الأصلي.
class UserService {
  static const String _userKey = 'current_user';

  /// تحميل بيانات المستخدم من التخزين المحلي
  static Future<User?> loadUserFromStorage() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString(_userKey);

    if (userJson == null || userJson.isEmpty) return null;

    try {
      final Map<String, dynamic> data = jsonDecode(userJson);
      return User.fromJson(data);
    } catch (e) {
      print('Error parsing user data: $e');
      return null;
    }
  }

  /// حفظ بيانات المستخدم في التخزين المحلي
  static Future<void> saveUserToStorage(User user) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = jsonEncode(user.toJson());
    await prefs.setString(_userKey, jsonString);
  }

  /// حذف بيانات المستخدم من التخزين (تسجيل الخروج)
  static Future<void> clearUserData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_userKey);
  }

  /// جلب المستخدم الحالي بدون تحميل من API (من الكاش فقط)
  static Future<User?> getCurrentUser() async {
    return await loadUserFromStorage();
  }

  /// فحص هل يوجد مستخدم مسجل دخول حالياً
  static Future<bool> isLoggedIn() async {
    final user = await loadUserFromStorage();
    return user != null && (user.token?.isNotEmpty ?? false);
  }
}
