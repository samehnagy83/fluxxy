class Endpoints {
  static const String login = 'auth/login';
  static const String register = 'auth/register';
  static const String forgotPassword = 'auth/forgot-password';
  static const String profile = 'user/profile';
}
