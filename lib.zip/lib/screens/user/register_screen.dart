import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../common/config/theme_config.dart';
import '../../common/widgets/app_logo.dart';
import '../../common/widgets/custom_text_field.dart';
import '../../common/widgets/primary_button.dart';
import '../../common/widgets/divider_line.dart';
import '../../common/widgets/social_button.dart';
import '../../models/user_model.dart';
import '../../common/tools/constants.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  bool _loading = false;

  Future<void> _onRegisterPressed() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);

    final userModel = context.read<UserModel>();

    final success = await userModel.register(
      context, // ✅ نمرر الـ context علشان نقدر نعرض الرسائل من UIFeedback
      _nameCtrl.text.trim(),
      _emailCtrl.text.trim(),
      _passwordCtrl.text.trim(),
    );

    setState(() => _loading = false);

    if (success && mounted) {
      Navigator.of(context).pushReplacementNamed(AppConstants.routeHome);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 32),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 10),
                const AppLogo(title: 'Create Account'),
                const SizedBox(height: 30),

                /// 🧍 Full name field
                CustomTextField(
                  label: 'Full Name',
                  hintText: 'Enter your name',
                  icon: Icons.person_outline,
                  controller: _nameCtrl,
                  validator: (value) =>
                      (value == null || value.isEmpty) ? 'Enter your name' : null,
                ),

                /// 📧 Email field
                CustomTextField(
                  label: 'Email',
                  hintText: 'Enter your email',
                  icon: Icons.email_outlined,
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) =>
                      (value == null || value.isEmpty) ? 'Enter your email' : null,
                ),

                /// 🔒 Password field
                CustomTextField(
                  label: 'Password',
                  hintText: 'Enter your password',
                  icon: Icons.lock_outline,
                  controller: _passwordCtrl,
                  obscureText: true,
                  validator: (value) => (value == null || value.isEmpty)
                      ? 'Enter your password'
                      : null,
                ),

                const SizedBox(height: 20),

                /// Register button
                PrimaryButton(
                  text: 'Register',
                  loading: _loading,
                  onPressed: _onRegisterPressed,
                ),

                const SizedBox(height: 20),

                /// Divider
                const DividerLine('OR sign up with'),
                const SizedBox(height: 20),

                /// Social login buttons
                SocialButton(
                  type: SocialType.google,
                  onPressed: () {
                    // TODO: Implement Google sign-up
                  },
                ),
                const SizedBox(height: 10),
                SocialButton(
                  type: SocialType.apple,
                  onPressed: () {
                    // TODO: Implement Apple sign-up
                  },
                ),
                const SizedBox(height: 10),
                SocialButton(
                  type: SocialType.phone,
                  onPressed: () {
                    // TODO: Implement phone sign-up
                  },
                ),

                const SizedBox(height: 30),

                /// Back to login
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'Already have an account? ',
                      style: TextStyle(color: ThemeConfig.textColor),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.of(context)
                            .pushReplacementNamed(AppConstants.routeLogin);
                      },
                      child: const Text(
                        'Login',
                        style: TextStyle(
                          color: ThemeConfig.secondaryColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
