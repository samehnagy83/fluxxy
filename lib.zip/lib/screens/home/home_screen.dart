import 'package:flutter/material.dart';
import 'package:fluxxy/common/config/theme_elements.dart';
import 'package:fluxxy/common/tools/auth_guard.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AuthGuard(
      child: Scaffold(
        appBar: ThemeElements.appBar('Home', actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              // await UserService.logout();
              // if (context.mounted) {
              //   Navigator.of(context).pushReplacementNamed(AppConstants.routeLogin);
              // }
            },
          ),
        ]),
        body: const Center(
          child: Text('Welcome to the Home Screen!'),
        ),
      ),
    );
  }
}
