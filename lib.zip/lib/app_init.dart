import 'package:flutter/material.dart';
import 'package:fluxxy/common/config/theme_config.dart';
import 'package:fluxxy/models/user_model.dart';
import 'package:provider/provider.dart';
import 'common/tools/constants.dart';
import 'common/config/app_config.dart';
import 'common/storage/local_storage.dart';

/// AppInit هو المسئول عن تجهيز كل شيء بعد SplashScreen
/// - تهيئة التخزين
/// - تحميل المستخدم
/// - توجيهه حسب حالته
class AppInit extends StatefulWidget {
  const AppInit({super.key});

  @override
  State<AppInit> createState() => _AppInitState();
}

class _AppInitState extends State<AppInit> {
  bool _initializing = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    try {
      // 1️⃣ تهيئة التخزين المحلي
      await LocalStorage.init();

      // 2️⃣ الوصول إلى UserModel من الـ Provider
      final userModel = context.read<UserModel>();
      await userModel.loadFromStorage();

      // 3️⃣ انتظار بسيط لتزامن المدة مع شاشة الـ Splash
      await Future.delayed(
        Duration(milliseconds: LoadingConfig.splashScreen['duration'] as int),
      );

      // 5️⃣ بعد التحميل نقرر الوجهة
      if (!mounted) return;

      if (userModel.loggedIn) {
        Navigator.of(context).pushReplacementNamed(AppConstants.routeHome);
      } else {
        Navigator.of(context).pushReplacementNamed(AppConstants.routeLogin);
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'An error occurred during initialization: $e';
      });
    } finally {
      setState(() => _initializing = false);
    }
  }

  // @override
  // Widget build(BuildContext context) {
  //   return const Scaffold(
  //     body: Center(
  //       child: CircularProgressIndicator(),
  //     ),
  //   );
  // }

   @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.backgroundColor,
      body: Center(
        child: _initializing
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text(
                    'Preparing the application...',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              )
            : _errorMessage != null
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        _errorMessage!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.red, fontSize: 16),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _initializeApp,
                        child: const Text('try again'),
                      ),
                    ],
                  )
                : const Text('Data uploaded successfully ✅'),
      ),
    );
  }
  
}
